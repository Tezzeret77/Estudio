// Esto es un comentario en JS
document.querySelector("#textoTerciario").textContent =
  "Sos re putooooooooooooooooooooo";
document.querySelector("#textoTerciario").textContent = "Sos re puto";
